import java.sql.*;

public class VehicleDBController {
	private static String hostname = "localhost"; 
    private static String port = "3306"; 
    private static String dbname = "sysarch_w4"; 
    private static String user = "root"; 
    private static String password = "";
    private static Connection conn = null;
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

	/**
     * A connection to the database will be established and all table values
     * will be read.
     * 
     * @throws SQLException
     *             If there couldn't be established a connection to database.
     * @throws ClassNotFoundException
     *             If the database driver couldn't be found.
     */
	public static void createConnection() throws SQLException, ClassNotFoundException {
        
		try {
		// driver initialization
		System.out.println("* Load driver"); 
        Class.forName(DRIVER);
		}
        catch (Exception e) { 
            System.err.println("Unable to load driver."); 
            e.printStackTrace(); 
        } 
        // Url for the connection to the database
        String mySqlUrl = "jdbc:mysql://" + hostname + ":" + port + "/" + dbname;
        // Establish connection.
        System.out.println("* Establish connection to database"); 
        conn = DriverManager.getConnection(mySqlUrl, user, password); 
    }
	 
	 /**
	     * Close the database connection and free the local port
	     * 
	     * @throws SQLException
	     *             If connection couldn't disconnect.
	     */	    
	 public static void closeProgramm() throws SQLException {
		 	System.out.println("* Database-Connection finished"); 
	        conn.close();
	    }
}		